Contains two demos:
  1. DeserializationDemo
  2. SerializationDemo
  
Needed jars on classpath:
  - jsefa.jar
