Contains two demos showing how CVS files with headers could be handled:
  1. DeserializationDemo
  2. SerializationDemo
  
Needed jars on classpath:
  - jsefa.jar
