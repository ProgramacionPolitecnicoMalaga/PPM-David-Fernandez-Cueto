Contains three demos:
  1. XmlPerformanceDemo
  2. CsvPerformanceDemo
  3. FlrPerformanceDemo
  
Needed jars on classpath:
  - jsefa.jar
  - for first demo only:
    - jsr173_1.0_api.jar
    - wstx-asl-3.2.6.jar