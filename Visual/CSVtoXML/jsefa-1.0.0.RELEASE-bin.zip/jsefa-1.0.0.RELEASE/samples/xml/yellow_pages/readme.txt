Contains two demos:
  1. DeserializationDemo
  2. SerializationDemo
  
Needed jars on classpath:
  - jsefa.jar
  - for running on Java 5 only:
    - jsr173_1.0_api.jar
    - wstx-asl-3.2.6.jar